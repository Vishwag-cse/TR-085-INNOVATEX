"""
Academic Plagiarism & AI Content Detector — Flask Backend
Main application with REST API endpoints.
"""

import os
import sys
import time
import json
from datetime import datetime
from functools import wraps

from flask import Flask, request, jsonify, send_from_directory, session
from flask_cors import CORS

# Add parent dir to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.models import (
    init_db, create_user, get_user_by_email, get_all_users,
    create_document, get_document, get_documents_by_user, get_all_documents,
    create_scan_result, get_scan_result, get_scan_result_by_document,
    get_all_scan_results, get_system_stats
)

# ─── App Setup ─────────────────────────────
app = Flask(__name__, static_folder=None)
app.secret_key = 'academic-plagiarism-detector-secret-key-2024'
CORS(app, supports_credentials=True)

# Frontend directory
FRONTEND_DIR = os.path.dirname(os.path.dirname(__file__))


# ─── Serve Frontend ────────────────────────

@app.route('/')
def serve_frontend():
    return send_from_directory(FRONTEND_DIR, 'Academic_Resilience_Platform (1).html')


@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory(FRONTEND_DIR, filename)


# ─── Auth Endpoints ────────────────────────

@app.route('/api/signup', methods=['POST'])
def signup():
    data = request.json
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    required = ['full_name', 'email', 'password']
    for field in required:
        if field not in data or not data[field]:
            return jsonify({'error': f'{field} is required'}), 400

    # Check if user exists
    existing = get_user_by_email(data['email'])
    if existing:
        return jsonify({'error': 'Email already registered'}), 409

    # Hash password
    try:
        import bcrypt
        password_hash = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    except ImportError:
        import hashlib
        password_hash = hashlib.sha256(data['password'].encode('utf-8')).hexdigest()

    user_id = create_user(
        full_name=data['full_name'],
        email=data['email'],
        phone=data.get('phone', ''),
        password_hash=password_hash,
        role=data.get('role', 'student'),
        status='active'  # Auto-approve for demo
    )

    if user_id is None:
        return jsonify({'error': 'Failed to create account'}), 500

    return jsonify({
        'message': 'Account created successfully',
        'user_id': user_id,
        'status': 'active'
    }), 201


@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    if not data or 'email' not in data or 'password' not in data:
        return jsonify({'error': 'Email and password required'}), 400

    user = get_user_by_email(data['email'])
    if not user:
        return jsonify({'error': 'Invalid email or password'}), 401

    # Verify password
    try:
        import bcrypt
        valid = bcrypt.checkpw(data['password'].encode('utf-8'), user['password_hash'].encode('utf-8'))
    except (ImportError, ValueError):
        import hashlib
        valid = user['password_hash'] == hashlib.sha256(data['password'].encode('utf-8')).hexdigest()

    if not valid:
        return jsonify({'error': 'Invalid email or password'}), 401

    role = data.get('role', user['role'])

    session['user_id'] = user['id']
    session['role'] = role

    return jsonify({
        'message': 'Login successful',
        'user': {
            'id': user['id'],
            'full_name': user['full_name'],
            'email': user['email'],
            'role': role,
            'status': user['status']
        }
    })


@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'})


# ─── Document Scanning ─────────────────────

@app.route('/api/scan', methods=['POST'])
def scan_document():
    """Upload and scan a document for plagiarism & AI content."""
    start_time = time.time()

    # Get text content
    text = None
    filename = 'pasted_text.txt'
    user_id = session.get('user_id', 'guest')

    if 'file' in request.files:
        file = request.files['file']
        filename = file.filename or 'uploaded_file'

        # Read file content
        if filename.lower().endswith('.txt'):
            text = file.read().decode('utf-8', errors='ignore')
        elif filename.lower().endswith('.pdf'):
            try:
                import PyPDF2
                import io
                reader = PyPDF2.PdfReader(io.BytesIO(file.read()))
                text = '\n'.join([page.extract_text() or '' for page in reader.pages])
            except Exception as e:
                return jsonify({'error': f'Failed to read PDF: {str(e)}'}), 400
        elif filename.lower().endswith('.docx'):
            try:
                import docx
                import io
                doc = docx.Document(io.BytesIO(file.read()))
                text = '\n'.join([para.text for para in doc.paragraphs])
            except Exception as e:
                return jsonify({'error': f'Failed to read DOCX: {str(e)}'}), 400
        else:
            text = file.read().decode('utf-8', errors='ignore')
    elif request.json and 'text' in request.json:
        text = request.json['text']
        filename = request.json.get('filename', 'pasted_text.txt')
        user_id = request.json.get('user_id', session.get('user_id', 'guest'))
    elif request.form and 'text' in request.form:
        text = request.form['text']
        filename = request.form.get('filename', 'pasted_text.txt')

    if not text or len(text.strip()) < 50:
        return jsonify({'error': 'Please provide at least 50 characters of text to analyze'}), 400

    word_count = len(text.split())

    # Save document
    doc_id = create_document(user_id, filename, text, word_count)

    # Run detection
    try:
        from backend.detection.plagiarism_engine import detect_plagiarism
        from backend.detection.ai_detector import detect_ai_content
        from backend.detection.report_generator import generate_report

        print(f"[Scan] Starting analysis of '{filename}' ({word_count} words)...")

        # Run plagiarism detection
        plag_results = detect_plagiarism(text)

        # Run AI content detection
        ai_results = detect_ai_content(text)

        # Generate report
        doc_info = {'filename': filename, 'word_count': word_count}
        report = generate_report(plag_results, ai_results, doc_info)

        total_time = round(time.time() - start_time, 2)
        report['metrics']['total_processing_time'] = total_time

        # Determine risk level
        risk_level = report['summary']['overall_risk_level']

        # Save scan result
        scan_id = create_scan_result(
            document_id=doc_id,
            plagiarism_score=report['summary']['plagiarism_score'],
            ai_score=report['summary']['ai_content_score'],
            risk_level=risk_level,
            report_json=report,
            processing_time=total_time
        )

        print(f"[Scan] Analysis complete in {total_time}s — Plagiarism: {report['summary']['plagiarism_score']}%, AI: {report['summary']['ai_content_score']}%, Risk: {risk_level}")

        return jsonify({
            'success': True,
            'scan_id': scan_id,
            'document_id': doc_id,
            'report': report
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500


@app.route('/api/scan/<scan_id>', methods=['GET'])
def get_scan(scan_id):
    """Get a specific scan result."""
    result = get_scan_result(scan_id)
    if not result:
        return jsonify({'error': 'Scan not found'}), 404
    return jsonify(result)


@app.route('/api/documents', methods=['GET'])
def list_documents():
    """List all documents (for faculty/admin)."""
    docs = get_all_documents()
    return jsonify({'documents': docs})


@app.route('/api/documents/user/<user_id>', methods=['GET'])
def list_user_documents(user_id):
    """List documents for a specific user."""
    docs = get_documents_by_user(user_id)
    return jsonify({'documents': docs})


@app.route('/api/documents/<doc_id>/report', methods=['GET'])
def get_document_report(doc_id):
    """Get the full report for a document."""
    result = get_scan_result_by_document(doc_id)
    if not result:
        return jsonify({'error': 'No scan results for this document'}), 404
    return jsonify(result)


# ─── Admin/Stats Endpoints ─────────────────

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get system statistics for admin dashboard."""
    stats = get_system_stats()
    return jsonify(stats)


@app.route('/api/scans', methods=['GET'])
def list_scans():
    """List all scan results (admin view)."""
    results = get_all_scan_results()
    return jsonify({'scans': results})


@app.route('/api/users', methods=['GET'])
def list_users():
    """List all users (admin view)."""
    users = get_all_users()
    return jsonify({'users': users})


# ─── Health Check ──────────────────────────

@app.route('/api/health', methods=['GET'])
def health_check():
    """API health check with model status."""
    from backend.detection.plagiarism_engine import _model as plag_model
    from backend.detection.ai_detector import _classifier as ai_model

    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'database': 'MongoDB',
        'models': {
            'plagiarism_engine': 'loaded' if plag_model and plag_model != 'FAILED' else 'not_loaded',
            'ai_detector': 'loaded' if ai_model and ai_model != 'FAILED' else 'not_loaded'
        },
        'version': '1.1.0'
    })


# ─── Seed Demo Data ────────────────────────

def seed_demo_data():
    """Create demo users for quick testing."""
    import hashlib

    demos = [
        ('Alex Johnson', 'alex@university.edu', '9876543210', 'student'),
        ('Dr. Sarah Smith', 'sarah@university.edu', '9876543211', 'faculty'),
        ('Admin User', 'admin@university.edu', '9876543212', 'admin'),
    ]

    for name, email, phone, role in demos:
        existing = get_user_by_email(email)
        if not existing:
            try:
                import bcrypt
                pw_hash = bcrypt.hashpw(b'password123', bcrypt.gensalt()).decode('utf-8')
            except ImportError:
                pw_hash = hashlib.sha256(b'password123').hexdigest()

            create_user(name, email, phone, pw_hash, role, 'active')
            print(f"[Seed] Created demo user: {email} (role: {role}, password: password123)")


# ─── Main ──────────────────────────────────

if __name__ == '__main__':
    print("=" * 60)
    print("  Academic Plagiarism & AI Content Detector")
    print("  Backend Server v1.0")
    print("=" * 60)

    # Initialize database
    init_db()

    # Seed demo data
    seed_demo_data()

    print("\n[Server] Starting Flask server on http://localhost:5000")
    print("[Server] Frontend: http://localhost:5000")
    print("[Server] API Base: http://localhost:5000/api")
    print("[Server] Demo credentials:")
    print("  Student:  alex@university.edu / password123")
    print("  Faculty:  sarah@university.edu / password123")
    print("  Admin:    admin@university.edu / password123")
    print("=" * 60)

    app.run(host='0.0.0.0', port=5000, debug=True)
